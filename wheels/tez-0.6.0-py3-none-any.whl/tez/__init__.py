from .callbacks import Callback
from .model import Tez, TezConfig
from .model.model import Model


__version__ = "0.6.0"
