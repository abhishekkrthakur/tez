from .config import TezConfig
from .tez import Tez
